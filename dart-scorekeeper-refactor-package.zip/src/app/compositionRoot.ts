import { IndexedDbMatchRepository, IndexedDbPlayerRepository, LocalSettingsRepository, clearLocalData } from '../infrastructure/persistence/IndexedDbRepositories';
export const services = { matches:new IndexedDbMatchRepository(), players:new IndexedDbPlayerRepository(), settings:new LocalSettingsRepository(), clearLocalData, id:()=>crypto.randomUUID(), now:()=>new Date().toISOString() };
