import { openDB, type DBSchema, type IDBPDatabase } from "idb";
import type { Match, Player } from "../../domain/match/models";
import type {
  ActiveMatchRecord,
  MatchRepository,
  PlayerRepository,
  SettingsRepository,
} from "../../application/ports/repositories";

interface DartsDb extends DBSchema {
  matches: { key: string; value: Match };
  players: { key: string; value: Player };
  meta: { key: string; value: unknown };
}
let database: Promise<IDBPDatabase<DartsDb>> | undefined;
const db = (): Promise<IDBPDatabase<DartsDb>> =>
  (database ??= openDB<DartsDb>("dart-scorekeeper", 1, {
    upgrade(store) {
      if (!store.objectStoreNames.contains("matches"))
        store.createObjectStore("matches", { keyPath: "id" });
      if (!store.objectStoreNames.contains("players"))
        store.createObjectStore("players", { keyPath: "id" });
      if (!store.objectStoreNames.contains("meta"))
        store.createObjectStore("meta");
    },
  }));

const isRecord = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null;
const isStringArray = (value: unknown): value is string[] => Array.isArray(value) && value.every((item) => typeof item === "string");
function isDart(value: unknown): boolean {
  if (!isRecord(value) || typeof value.kind !== "string") return false;
  if (["miss", "bull", "outer_bull"].includes(value.kind)) return true;
  return value.kind === "number" && typeof value.segment === "number" && Number.isInteger(value.segment) && value.segment >= 1 && value.segment <= 20 && [1,2,3].includes(Number(value.multiplier));
}
function isVisit(value: unknown): boolean { return isRecord(value) && typeof value.id === "string" && typeof value.playerId === "string" && Array.isArray(value.darts) && value.darts.length <= 3 && value.darts.every(isDart) && typeof value.awardedScore === "number"; }
function isMatch(value: unknown): value is Match {
  if (!isRecord(value) || typeof value.id !== "string" || typeof value.createdAt !== "string" || !["in_progress","completed","abandoned"].includes(String(value.status)) || !isStringArray(value.players) || value.players.length < 2 || new Set(value.players).size !== value.players.length || !Number.isInteger(value.currentPlayerIndex) || Number(value.currentPlayerIndex) < 0 || Number(value.currentPlayerIndex) >= value.players.length || !Array.isArray(value.confirmedVisits) || !value.confirmedVisits.every(isVisit) || !isRecord(value.state)) return false;
  if (value.mode === "x01") return value.state.kind === "x01" && typeof value.state.targetLegWins === "number" && isRecord(value.state.remaining) && isRecord(value.state.legsWon);
  return value.mode === "fixed_visits" && value.state.kind === "fixed_visits" && typeof value.state.visitsPerPlayer === "number" && isRecord(value.state.totals) && isRecord(value.state.regulationCompleted);
}
function isActive(value: unknown): value is ActiveMatchRecord {
  return isRecord(value) && (value.schemaVersion === undefined || value.schemaVersion === 1) && isMatch(value.current) && (value.previous === undefined || isMatch(value.previous));
}

export class IndexedDbMatchRepository implements MatchRepository {
  async saveActive(record: ActiveMatchRecord): Promise<void> {
    await (await db()).put(
      "meta",
      structuredClone({ schemaVersion: 1, ...record }),
      "activeMatch",
    );
  }
  async loadActive(): Promise<ActiveMatchRecord | undefined> {
    const value = await (await db()).get("meta", "activeMatch");
    if (value === undefined) return undefined;
    if (!isActive(value))
      throw new Error("Сохранённый матч повреждён. Сбросьте локальные данные.");
    return value.previous === undefined
      ? { current: value.current }
      : { current: value.current, previous: value.previous };
  }
  async clearActive(): Promise<void> {
    await (await db()).delete("meta", "activeMatch");
  }
  async saveToHistory(match: Match): Promise<void> {
    await (await db()).put("matches", structuredClone(match));
  }
  async archiveAndClearActive(match: Match): Promise<void> {
    const database = await db();
    const transaction = database.transaction(["matches", "meta"], "readwrite");
    await transaction.objectStore("matches").put(structuredClone(match));
    await transaction.objectStore("meta").delete("activeMatch");
    await transaction.done;
  }
  async listHistory(): Promise<readonly Match[]> {
    const values = await (await db()).getAll("matches");
    return values
      .filter(isMatch)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
}
export class IndexedDbPlayerRepository implements PlayerRepository {
  async list(): Promise<readonly Player[]> {
    return (await (await db()).getAll("players")).sort((a, b) =>
      a.name.localeCompare(b.name, "ru"),
    );
  }
  async save(player: Player): Promise<void> {
    await (await db()).put("players", structuredClone(player));
  }
}
export class LocalSettingsRepository implements SettingsRepository {
  async load(): Promise<Readonly<Record<string, string>>> {
    try {
      return JSON.parse(
        localStorage.getItem("darts-settings-v1") ?? "{}",
      ) as Record<string, string>;
    } catch {
      return {};
    }
  }
  async save(values: Readonly<Record<string, string>>): Promise<void> {
    localStorage.setItem("darts-settings-v1", JSON.stringify(values));
  }
}
export async function clearLocalData(): Promise<void> {
  if (database) {
    (await database).close();
    database = undefined;
  }
  await indexedDB.deleteDatabase("dart-scorekeeper");
  localStorage.removeItem("darts-settings-v1");
}
