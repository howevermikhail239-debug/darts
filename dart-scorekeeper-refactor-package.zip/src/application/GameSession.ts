import {
  addDraftThrow,
  emptyDraft,
  removeDraftThrow,
  replaceDraftThrow,
  resetDraft,
  truncateDraft,
  type VisitDraft,
} from "../domain/match/VisitDraft";
import {
  currentPlayerId,
  visitContext,
  type Match,
  type Visit,
} from "../domain/match/models";
import type { DartThrow } from "../domain/darts/DartThrow";
import type { DraftEvaluation } from "../domain/rules/GameRules";
import { rulesFor } from "../domain/rules/rulesFor";
import {
  finishAsDraw,
  startExtraRound,
} from "../domain/rules/FixedVisitsRules";
import type { MatchRepository } from "./ports/repositories";

export type IdGenerator = () => string;
export type Clock = () => string;
export type SessionSnapshot = Readonly<{
  match: Match;
  draft: VisitDraft;
  evaluation: DraftEvaluation;
  isConfirming: boolean;
  notice?: string;
}>;
export class GameSession {
  private draft: VisitDraft = emptyDraft();
  private checkpoints: Match[] = [];
  private confirming = false;
  private notice: string | undefined;
  constructor(
    private match: Match,
    private readonly repository: MatchRepository,
    private readonly id: IdGenerator,
    private readonly now: Clock,
    previous?: Match,
  ) {
    if (previous) this.checkpoints.push(previous);
  }
  snapshot(): SessionSnapshot {
    const value = {
      match: this.match,
      draft: this.draft,
      evaluation: rulesFor(this.match).evaluateDraft(this.draft, this.match),
      isConfirming: this.confirming,
    };
    return this.notice ? { ...value, notice: this.notice } : value;
  }
  record(dart: DartThrow, replaceIndex?: number): SessionSnapshot {
    this.ensureMutable();
    this.ensureInput();
    this.notice = undefined;
    this.draft =
      replaceIndex === undefined
        ? addDraftThrow(this.draft, dart)
        : replaceDraftThrow(this.draft, replaceIndex, dart);
    return this.normalize();
  }
  remove(index?: number): SessionSnapshot {
    this.ensureMutable();
    this.ensureInput();
    this.draft = removeDraftThrow(this.draft, index);
    this.notice = undefined;
    return this.snapshot();
  }
  reset(): SessionSnapshot {
    this.ensureMutable();
    this.draft = resetDraft();
    this.notice = undefined;
    return this.snapshot();
  }
  private normalize(): SessionSnapshot {
    const evaluation = rulesFor(this.match).evaluateDraft(
      this.draft,
      this.match,
    );
    if (evaluation.validDartCount < this.draft.darts.length) {
      this.draft = truncateDraft(this.draft, evaluation.validDartCount);
      this.notice = "Поздние дротики удалены: подход завершился раньше.";
    }
    return this.snapshot();
  }
  private ensureInput(): void {
    if (this.match.status !== "in_progress") throw new Error("Матч завершён");
    if (
      this.match.state.kind === "fixed_visits" &&
      this.match.state.awaitingTieDecision
    )
      throw new Error("Сначала выберите результат ничьей");
  }
  private ensureMutable(): void {
    if (this.confirming) throw new Error("Подтверждение уже выполняется");
  }
  async confirm(): Promise<SessionSnapshot> {
    if (this.confirming) return this.snapshot();
    this.ensureInput();
    const rules = rulesFor(this.match);
    const evaluation = rules.evaluateDraft(this.draft, this.match);
    if (evaluation.status === "in_progress")
      throw new Error(
        this.match.mode === "fixed_visits"
          ? "Введите ровно три дротика"
          : "Введите дротик",
      );
    this.confirming = true;
    try {
      const previous = this.match;
      const timestamp = this.now();
      const before = visitContext(previous);
      const playerId = currentPlayerId(previous);
      const provisionalResult =
        evaluation.status === "bust"
          ? "bust"
          : evaluation.status === "leg_won"
            ? "leg_won"
            : evaluation.status === "match_won"
              ? "match_won"
              : "scored";
      const afterScores = { ...before.scores };
      if (previous.state.kind === "x01")
        afterScores[playerId] =
          evaluation.remainingAfter ?? afterScores[playerId] ?? 501;
      else
        afterScores[playerId] =
          (afterScores[playerId] ?? 0) + evaluation.awardedScore;
      const provisionalVisit: Visit = Object.freeze({
        id: this.id(),
        matchId: previous.id,
        playerId,
        visitIndex: previous.confirmedVisits.length,
        ...(previous.state.kind === "x01"
          ? { legIndex: previous.state.currentLeg }
          : {}),
        darts: Object.freeze([...this.draft.darts]),
        physicalDartsUsed: evaluation.physicalDartsUsed,
        rawScore: evaluation.rawScore,
        awardedScore: evaluation.awardedScore,
        before,
        after: {
          scores: afterScores,
          currentPlayerIndex:
            (previous.currentPlayerIndex + 1) % previous.players.length,
          ...(previous.state.kind === "x01"
            ? { legIndex: previous.state.currentLeg }
            : {}),
        },
        result: provisionalResult,
        timestamp,
      });
      const applied = rules.applyConfirmedVisit(provisionalVisit, previous);
      const visit: Visit = Object.freeze({
        ...provisionalVisit,
        after: visitContext(applied),
      });
      const next: Match = {
        ...applied,
        confirmedVisits: [...applied.confirmedVisits.slice(0, -1), visit],
      };
      await this.repository.saveActive({ current: next, previous });
      this.checkpoints.push(previous);
      if (this.checkpoints.length > 20) this.checkpoints.shift();
      this.match = next;
      this.draft = emptyDraft();
      this.notice = undefined;
      return this.snapshot();
    } finally {
      this.confirming = false;
    }
  }
  async undo(): Promise<SessionSnapshot> {
    this.ensureMutable();
    const previous = this.checkpoints.at(-1);
    if (!previous) throw new Error("Нет подхода для отмены");
    const fallback = this.checkpoints.at(-2);
    await this.repository.saveActive(
      fallback
        ? { current: previous, previous: fallback }
        : { current: previous },
    );
    this.checkpoints.pop();
    this.match = previous;
    this.draft = emptyDraft();
    this.notice = "Предыдущий подход отменён.";
    return this.snapshot();
  }
  async extraRound(): Promise<SessionSnapshot> {
    this.ensureMutable();
    const next = startExtraRound(this.match);
    const previous = this.checkpoints.at(-1);
    await this.repository.saveActive(
      previous ? { current: next, previous } : { current: next },
    );
    this.match = next;
    return this.snapshot();
  }
  async completeDraw(): Promise<SessionSnapshot> {
    this.ensureMutable();
    const previous = this.match;
    const next = finishAsDraw(this.match, this.now());
    await this.repository.saveActive({ current: next, previous });
    this.checkpoints.push(previous);
    this.match = next;
    return this.snapshot();
  }
  async abandon(): Promise<Match> {
    this.ensureMutable();
    const next: Match = {
      ...this.match,
      status: "abandoned",
      completedAt: this.now(),
    };
    await this.repository.archiveAndClearActive(next);
    this.match = next;
    return this.match;
  }
  async finalize(): Promise<Match> {
    this.ensureMutable();
    if (this.match.status !== "completed")
      throw new Error("Матч ещё не завершён");
    await this.repository.archiveAndClearActive(this.match);
    this.checkpoints = [];
    return this.match;
  }
}
