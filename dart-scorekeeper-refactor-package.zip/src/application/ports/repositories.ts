import type { Match, Player } from '../../domain/match/models';

export type ActiveMatchRecord = Readonly<{ current: Match; previous?: Match }>;
export interface MatchRepository {
  saveActive(record: ActiveMatchRecord): Promise<void>;
  loadActive(): Promise<ActiveMatchRecord|undefined>;
  clearActive(): Promise<void>;
  saveToHistory(match: Match): Promise<void>;
  archiveAndClearActive(match: Match): Promise<void>;
  listHistory(): Promise<readonly Match[]>;
}
export interface PlayerRepository { list(): Promise<readonly Player[]>; save(player: Player): Promise<void>; }
export interface SettingsRepository { load(): Promise<Readonly<Record<string,string>>>; save(values: Readonly<Record<string,string>>): Promise<void>; }
