import { useState } from "react";
import {
  bull,
  miss,
  numberThrow,
  outerBull,
  type Multiplier,
} from "../../domain/darts/DartThrow";
import { checkoutRoutes } from "../../domain/rules/CheckoutRoutes";
import type { Player } from "../../domain/match/models";
import type {
  GameSession,
  SessionSnapshot,
} from "../../application/GameSession";
import { useWakeLock } from "../hooks/useWakeLock";
import { Scoreboard } from "../components/Scoreboard";
import { DraftPanel } from "../components/DraftPanel";
import { DartPad } from "../components/DartPad";
import { t } from "../strings";
type Props = {
  session: GameSession;
  initial: SessionSnapshot;
  players: readonly Player[];
  onChange: (s: SessionSnapshot) => void;
  onExit: () => void;
};
export function GamePage({
  session,
  initial,
  players,
  onChange,
  onExit,
}: Props) {
  const [snapshot, setSnapshot] = useState(initial);
  const [multiplier, setMultiplier] = useState<Multiplier>(1);
  const [selected, setSelected] = useState<number>();
  const [error, setError] = useState<string>();
  useWakeLock(snapshot.match.status === "in_progress");
  const update = (s: SessionSnapshot) => {
    setSnapshot(s);
    onChange(s);
    setError(undefined);
  };
  const enter = (dart: ReturnType<typeof miss>) => {
    try {
      update(session.record(dart, selected));
      setSelected(undefined);
      setMultiplier(1);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ошибка ввода");
    }
  };
  const confirm = async () => {
    try {
      const pending = session.confirm();
      update(session.snapshot());
      update(await pending);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ошибка сохранения");
    }
  };
  const m = snapshot.match;
  const currentName =
    players.find((p) => p.id === m.players[m.currentPlayerIndex])?.name ??
    "Игрок";
  const routes =
    m.state.kind === "x01" && snapshot.evaluation.remainingAfter
      ? checkoutRoutes(
          snapshot.evaluation.remainingAfter,
          3 - snapshot.draft.darts.length,
        )
      : [];
  if (m.status === "completed")
    return (
      <Summary
        snapshot={snapshot}
        players={players}
        onUndo={async () => update(await session.undo())}
        onFinish={async () => {
          await session.finalize();
          onExit();
        }}
      />
    );
  return (
    <main className="game-page">
      <header className="game-header">
        <button
          className="text-icon"
          onClick={onExit}
          aria-label="На главный экран"
        >
          ‹
        </button>
        <div>
          <strong>
            {m.mode === "x01"
              ? `501 · до ${m.state.kind === "x01" ? m.state.targetLegWins : 0} побед`
              : `Серия · ${m.state.kind === "fixed_visits" ? m.state.visitsPerPlayer : 0} подходов`}
          </strong>
          <span>
            {m.state.kind === "x01"
              ? `Лег ${m.state.currentLeg}`
              : m.state.extraRoundInProgress
                ? `Дополнительный подход ${m.state.extraRoundsCompleted + 1}`
                : `Подход ${Math.min(...Object.values(m.state.regulationCompleted)) + 1} из ${m.state.visitsPerPlayer}`}
          </span>
        </div>
        <button
          className="text-icon"
          onClick={() => void session.abandon().then(onExit)}
          aria-label={t.abandon}
        >
          ×
        </button>
      </header>
      <Scoreboard match={m} players={players} />
      <div className="current-label">
        ● {t.currentVisit}: <strong>{currentName}</strong>
      </div>
      <DraftPanel
        snapshot={snapshot}
        selected={selected}
        onSelect={(i) => setSelected(selected === i ? undefined : i)}
        onRemove={() => update(session.remove())}
        onReset={() => {
          update(session.reset());
          setMultiplier(1);
          setSelected(undefined);
        }}
        onConfirm={() => void confirm()}
      />
      {routes.length ? (
        <div className="checkout">
          <span>Варианты закрытия</span>
          {routes.map((r) => (
            <b key={r}>{r}</b>
          ))}
        </div>
      ) : null}
      {m.state.kind === "fixed_visits" && m.state.awaitingTieDecision ? (
        <div className="tie-panel">
          <h2>{t.draw}</h2>
          <button
            className="primary"
            onClick={() => void session.extraRound().then(update)}
          >
            {t.extra}
          </button>
          <button
            className="secondary"
            onClick={() => void session.completeDraw().then(update)}
          >
            {t.finishDraw}
          </button>
        </div>
      ) : (
        <DartPad
          multiplier={multiplier}
          disabled={!snapshot.evaluation.canAddNextDart && selected === undefined}
          onMultiplier={setMultiplier}
          onNumber={(n) => enter(numberThrow(n, multiplier))}
          onBull={(kind) =>
            enter(
              kind === "outer"
                ? outerBull()
                : kind === "bull"
                  ? bull()
                  : miss(),
            )
          }
        />
      )}{" "}
      {error ? (
        <div className="error" role="alert">
          {error}
        </div>
      ) : null}
      <button
        className="undo-link"
        onClick={() =>
          void session
            .undo()
            .then(update)
            .catch((e) => setError(e instanceof Error ? e.message : "Ошибка"))
        }
      >
        {t.undo}
      </button>
    </main>
  );
}

function Summary({
  snapshot,
  players,
  onUndo,
  onFinish,
}: {
  snapshot: SessionSnapshot;
  players: readonly Player[];
  onUndo: () => Promise<void>;
  onFinish: () => Promise<void>;
}) {
  const m = snapshot.match;
  return (
    <main className="summary-page">
      <p className="eyeline">{m.mode === "x01" ? "501" : "Серия завершена"}</p>
      <h1>
        {m.winnerId
          ? `${players.find((p) => p.id === m.winnerId)?.name} победил${players.find((p) => p.id === m.winnerId)?.name.endsWith("а") ? "а" : ""}`
          : t.draw}
      </h1>
      <Scoreboard match={m} players={players} />
      <section className="summary-actions">
        <button className="secondary" onClick={() => void onUndo()}>
          {t.undo}
        </button>
        <button className="primary" onClick={() => void onFinish()}>
          {t.finish}
        </button>
      </section>
    </main>
  );
}
