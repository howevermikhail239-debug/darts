import { notationOf, scoreOf } from '../../domain/darts/DartThrow';
import type { SessionSnapshot } from '../../application/GameSession';
import { t } from '../strings';
type Props={snapshot:SessionSnapshot;selected:number|undefined;onSelect:(index:number)=>void;onRemove:()=>void;onReset:()=>void;onConfirm:()=>void};
export function DraftPanel({snapshot,selected,onSelect,onRemove,onReset,onConfirm}:Props){const {draft,evaluation,isConfirming}=snapshot;const ready=evaluation.status!=='in_progress';return <section className="draft-panel">
  <div className="section-heading"><h2>{t.currentVisit}</h2>{selected!==undefined?<span>{t.replace} {selected+1}</span>:null}</div>
  <div className="dart-slots">{[0,1,2].map(i=>{const dart=draft.darts[i];return <button key={i} className={`${dart?'filled':''} ${selected===i?'selected':''}`} onClick={()=>dart&&onSelect(i)} aria-label={dart?`${t.dart} ${i+1}: ${notationOf(dart)}, заменить`:`${t.dart} ${i+1}: пусто`}><small>{t.dart} {i+1}</small><b>{dart?notationOf(dart):'—'}</b><span>{dart?scoreOf(dart):'пусто'}</span></button>})}</div>
  {snapshot.notice?<div className="notice" role="status">{snapshot.notice}</div>:null}
  <div className={`evaluation ${evaluation.status==='bust'?'danger':''}`}><div><small>{evaluation.status==='bust'?t.bust:'Сумма подхода'}</small><strong>{evaluation.status==='bust'?'0':evaluation.rawScore}</strong></div>{evaluation.remainingAfter!==undefined?<div><small>После подтверждения</small><strong>{evaluation.remainingAfter}</strong></div>:null}</div>
  {evaluation.reason?<p className="reason">{evaluation.reason}. Зачётные очки: 0.</p>:null}
  <div className="draft-actions"><button className="secondary" onClick={onRemove} disabled={!draft.darts.length}>Удалить последний</button><button className="secondary" onClick={onReset} disabled={!draft.darts.length}>{t.reset}</button><button className="primary" onClick={onConfirm} disabled={!ready||isConfirming}>{isConfirming?'Сохраняем…':evaluation.status==='bust'?`${t.confirm} перебор`:`${t.confirm} ${evaluation.awardedScore}`}</button></div>
  {!ready?<p className="hint">{snapshot.match.mode==='fixed_visits'?'Введите все три физических дротика':'Можно подтвердить после трёх дротиков или досрочного завершения'}</p>:null}
  </section>}
