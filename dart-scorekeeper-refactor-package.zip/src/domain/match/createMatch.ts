import type { Match, PlayerId } from "./models";

export type MatchSetup =
  | Readonly<{
      mode: "x01";
      targetLegWins: number;
      startingPlayerIndex: number;
    }>
  | Readonly<{
      mode: "fixed_visits";
      visitsPerPlayer: number;
      startingPlayerIndex: number;
    }>;

export function createMatch(
  id: string,
  playerIds: readonly PlayerId[],
  setup: MatchSetup,
  now: string,
): Match {
  if (playerIds.length < 2 || new Set(playerIds).size !== playerIds.length)
    throw new Error("Матчу нужны как минимум два разных игрока");
  if (
    !Number.isInteger(setup.startingPlayerIndex) ||
    setup.startingPlayerIndex < 0 ||
    setup.startingPlayerIndex >= playerIds.length
  )
    throw new Error("Некорректный начинающий");
  if (setup.mode === "x01") {
    if (![1, 2, 3, 5].includes(setup.targetLegWins))
      throw new Error("Допустимо до 1, 2, 3 или 5 побед");
    const state: Match["state"] = {
      kind: "x01",
      targetLegWins: setup.targetLegWins,
      remaining: Object.fromEntries(playerIds.map((p) => [p, 501])),
      legsWon: Object.fromEntries(playerIds.map((p) => [p, 0])),
      currentLeg: 1,
      legStarterIndex: setup.startingPlayerIndex,
    };
    return Object.freeze({
      id,
      createdAt: now,
      status: "in_progress",
      mode: "x01",
      players: [...playerIds],
      startingPlayerIndex: setup.startingPlayerIndex,
      currentPlayerIndex: setup.startingPlayerIndex,
      confirmedVisits: [],
      state,
    });
  }
  if (
    !Number.isInteger(setup.visitsPerPlayer) ||
    setup.visitsPerPlayer < 1 ||
    setup.visitsPerPlayer > 999
  )
    throw new Error("Количество подходов должно быть от 1 до 999");
  const state: Match["state"] = {
    kind: "fixed_visits",
    visitsPerPlayer: setup.visitsPerPlayer,
    totals: Object.fromEntries(playerIds.map((p) => [p, 0])),
    regulationCompleted: Object.fromEntries(playerIds.map((p) => [p, 0])),
    extraRoundsCompleted: 0,
    extraRoundInProgress: false,
    awaitingTieDecision: false,
    drawCompleted: false,
  };
  return Object.freeze({
    id,
    createdAt: now,
    status: "in_progress",
    mode: "fixed_visits",
    players: [...playerIds],
    startingPlayerIndex: setup.startingPlayerIndex,
    currentPlayerIndex: setup.startingPlayerIndex,
    confirmedVisits: [],
    state,
  });
}
