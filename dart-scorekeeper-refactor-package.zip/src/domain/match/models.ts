import type { DartThrow } from '../darts/DartThrow';

export type PlayerId = string;
export type MatchId = string;
export type MatchStatus = 'in_progress'|'completed'|'abandoned';
export type Player = Readonly<{ id: PlayerId; name: string; createdAt: string }>;
export type VisitResult = 'scored'|'bust'|'leg_won'|'match_won'|'tie_pending';
export type VisitContext = Readonly<{ scores: Readonly<Record<PlayerId, number>>; currentPlayerIndex: number; legIndex?: number }>;
export type Visit = Readonly<{
  id: string; matchId: MatchId; playerId: PlayerId; visitIndex: number; legIndex?: number;
  darts: readonly DartThrow[]; physicalDartsUsed: number; rawScore: number; awardedScore: number;
  before: VisitContext; after: VisitContext; result: VisitResult; timestamp: string;
}>;
export type X01State = Readonly<{
  kind: 'x01'; targetLegWins: number; remaining: Readonly<Record<PlayerId, number>>;
  legsWon: Readonly<Record<PlayerId, number>>; currentLeg: number; legStarterIndex: number;
}>;
export type FixedVisitsState = Readonly<{
  kind: 'fixed_visits'; visitsPerPlayer: number; totals: Readonly<Record<PlayerId, number>>;
  regulationCompleted: Readonly<Record<PlayerId, number>>; extraRoundsCompleted: number;
  extraRoundInProgress: boolean; awaitingTieDecision: boolean; drawCompleted: boolean;
}>;
export type ModeState = X01State|FixedVisitsState;
export type Match = Readonly<{
  id: MatchId; createdAt: string; completedAt?: string; status: MatchStatus; mode: ModeState['kind'];
  players: readonly PlayerId[]; startingPlayerIndex: number; currentPlayerIndex: number;
  state: ModeState; confirmedVisits: readonly Visit[]; winnerId?: PlayerId;
}>;

export const scoresOf = (match: Match): Readonly<Record<PlayerId, number>> => match.state.kind === 'x01' ? match.state.remaining : match.state.totals;
export const currentPlayerId = (match: Match): PlayerId => {
  const id = match.players[match.currentPlayerIndex];
  if (!id) throw new Error('Некорректный индекс игрока');
  return id;
};
export const visitContext = (match: Match): VisitContext => {
  const base = {
    scores: Object.freeze({ ...scoresOf(match) }),
    currentPlayerIndex: match.currentPlayerIndex,
  };
  return Object.freeze(
    match.state.kind === 'x01'
      ? { ...base, legIndex: match.state.currentLeg }
      : base,
  );
};
