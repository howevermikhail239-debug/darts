import type { DartThrow } from '../darts/DartThrow';

export type VisitDraft = Readonly<{ darts: readonly DartThrow[] }>;
export const emptyDraft = (): VisitDraft => Object.freeze({ darts: Object.freeze([]) });
const freeze = (darts: readonly DartThrow[]): VisitDraft => Object.freeze({ darts: Object.freeze([...darts]) });
export function addDraftThrow(draft: VisitDraft, dart: DartThrow): VisitDraft {
  if (draft.darts.length >= 3) throw new Error('В подходе не может быть больше трёх дротиков');
  return freeze([...draft.darts, dart]);
}
export function replaceDraftThrow(draft: VisitDraft, index: number, dart: DartThrow): VisitDraft {
  if (index < 0 || index >= draft.darts.length) throw new RangeError('Нельзя заменить пустой слот');
  return freeze(draft.darts.map((item, i) => i === index ? dart : item));
}
export function removeDraftThrow(draft: VisitDraft, index = draft.darts.length - 1): VisitDraft {
  if (index < 0 || index >= draft.darts.length) return draft;
  return freeze(draft.darts.filter((_, i) => i !== index));
}
export const resetDraft = (): VisitDraft => emptyDraft();
export const truncateDraft = (draft: VisitDraft, length: number): VisitDraft => freeze(draft.darts.slice(0, length));
