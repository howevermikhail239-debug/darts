import { scoreOf } from "../darts/DartThrow";
import type { VisitDraft } from "../match/VisitDraft";
import { type FixedVisitsState, type Match, type Visit } from "../match/models";
import type { DraftEvaluation, GameRules } from "./GameRules";

export class FixedVisitsRules implements GameRules {
  evaluateDraft(draft: VisitDraft, match: Match): DraftEvaluation {
    if (match.state.kind !== "fixed_visits")
      throw new Error("FixedVisitsRules применимы только к серии");
    const rawScore = draft.darts.reduce((sum, dart) => sum + scoreOf(dart), 0);
    return {
      status: draft.darts.length === 3 ? "ready_to_confirm" : "in_progress",
      physicalDartsUsed: draft.darts.length,
      rawScore,
      awardedScore: rawScore,
      canAddNextDart: draft.darts.length < 3,
      validDartCount: draft.darts.length,
    };
  }
  applyConfirmedVisit(visit: Visit, match: Match): Match {
    if (match.state.kind !== "fixed_visits") throw new Error("Неверный режим");
    const state = match.state;
    const id = visit.playerId;
    const totals = {
      ...state.totals,
      [id]: (state.totals[id] ?? 0) + visit.awardedScore,
    };
    const regulationCompleted = state.extraRoundInProgress
      ? state.regulationCompleted
      : {
          ...state.regulationCompleted,
          [id]: (state.regulationCompleted[id] ?? 0) + 1,
        };
    const nextIndex = (match.currentPlayerIndex + 1) % match.players.length;
    const allRegulationDone = match.players.every(
      (playerId) =>
        (regulationCompleted[playerId] ?? 0) >= state.visitsPerPlayer,
    );
    const roundEnds = nextIndex === match.startingPlayerIndex;
    let awaitingTieDecision = state.awaitingTieDecision;
    let extraRoundInProgress = state.extraRoundInProgress;
    let extraRoundsCompleted = state.extraRoundsCompleted;
    if (allRegulationDone && (!state.extraRoundInProgress || roundEnds)) {
      const values = match.players.map((playerId) => totals[playerId] ?? 0);
      const maximum = Math.max(...values);
      awaitingTieDecision =
        values.filter((value) => value === maximum).length > 1;
      if (state.extraRoundInProgress && roundEnds) {
        extraRoundsCompleted += 1;
        extraRoundInProgress = false;
      }
      if (!awaitingTieDecision) {
        const winnerIndex = values.indexOf(maximum);
        return {
          ...match,
          state: {
            ...state,
            totals,
            regulationCompleted,
            extraRoundsCompleted,
            extraRoundInProgress: false,
            awaitingTieDecision: false,
          },
          confirmedVisits: [...match.confirmedVisits, visit],
          currentPlayerIndex: nextIndex,
          status: "completed",
          completedAt: visit.timestamp,
          winnerId: match.players[winnerIndex]!,
        };
      }
    }
    return {
      ...match,
      state: {
        ...state,
        totals,
        regulationCompleted,
        extraRoundsCompleted,
        extraRoundInProgress,
        awaitingTieDecision,
      } as FixedVisitsState,
      currentPlayerIndex: nextIndex,
      confirmedVisits: [...match.confirmedVisits, visit],
    };
  }
}

export function startExtraRound(match: Match): Match {
  if (match.state.kind !== "fixed_visits" || !match.state.awaitingTieDecision)
    throw new Error("Дополнительный подход сейчас недоступен");
  return {
    ...match,
    currentPlayerIndex: match.startingPlayerIndex,
    state: {
      ...match.state,
      awaitingTieDecision: false,
      extraRoundInProgress: true,
    },
  };
}
export function finishAsDraw(match: Match, now: string): Match {
  if (match.state.kind !== "fixed_visits" || !match.state.awaitingTieDecision)
    throw new Error("Матч не ожидает решения о ничьей");
  return {
    ...match,
    status: "completed",
    completedAt: now,
    state: { ...match.state, awaitingTieDecision: false, drawCompleted: true },
  };
}
