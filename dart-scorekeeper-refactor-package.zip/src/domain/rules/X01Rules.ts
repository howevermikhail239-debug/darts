import { isDouble, scoreOf } from '../darts/DartThrow';
import type { VisitDraft } from '../match/VisitDraft';
import { currentPlayerId, type Match, type Visit, type X01State } from '../match/models';
import type { DraftEvaluation, GameRules } from './GameRules';

export class X01Rules implements GameRules {
  evaluateDraft(draft: VisitDraft, match: Match): DraftEvaluation {
    if (match.state.kind !== 'x01') throw new Error('X01Rules применимы только к 501');
    const playerId = currentPlayerId(match);
    const start = match.state.remaining[playerId];
    if (start === undefined) throw new Error('Нет счёта текущего игрока');
    let remaining = start;
    let rawScore = 0;
    for (let i = 0; i < draft.darts.length; i += 1) {
      const dart = draft.darts[i];
      if (!dart) continue;
      const points = scoreOf(dart); rawScore += points; remaining -= points;
      if (remaining < 0 || remaining === 1 || (remaining === 0 && !isDouble(dart))) {
        return { status: 'bust', physicalDartsUsed: i + 1, rawScore, awardedScore: 0, canAddNextDart: false, remainingAfter: start, reason: remaining === 1 ? 'Остаток 1' : remaining === 0 ? 'Закрытие только удвоением' : 'Счёт ниже нуля', validDartCount: i + 1 };
      }
      if (remaining === 0) {
        const wins = (match.state.legsWon[playerId] ?? 0) + 1;
        return { status: wins >= match.state.targetLegWins ? 'match_won' : 'leg_won', physicalDartsUsed: i + 1, rawScore, awardedScore: rawScore, canAddNextDart: false, remainingAfter: 0, validDartCount: i + 1 };
      }
    }
    return { status: draft.darts.length === 3 ? 'ready_to_confirm' : 'in_progress', physicalDartsUsed: draft.darts.length, rawScore, awardedScore: rawScore, canAddNextDart: draft.darts.length < 3, remainingAfter: remaining, validDartCount: draft.darts.length };
  }

  applyConfirmedVisit(visit: Visit, match: Match): Match {
    if (match.state.kind !== 'x01') throw new Error('Неверный режим');
    const state = match.state; const playerId = visit.playerId;
    if (visit.result === 'leg_won' || visit.result === 'match_won') {
      const legsWon = { ...state.legsWon, [playerId]: (state.legsWon[playerId] ?? 0) + 1 };
      if (visit.result === 'match_won') return { ...match, state: { ...state, remaining: { ...state.remaining, [playerId]: 0 }, legsWon }, currentPlayerIndex: match.currentPlayerIndex, status: 'completed', completedAt: visit.timestamp, winnerId: playerId, confirmedVisits: [...match.confirmedVisits, visit] };
      const nextLeg = state.currentLeg + 1; const starter = (match.startingPlayerIndex + nextLeg - 1) % match.players.length;
      const reset = Object.fromEntries(match.players.map(id => [id, 501]));
      return { ...match, state: { ...state, remaining: reset, legsWon, currentLeg: nextLeg, legStarterIndex: starter } as X01State, currentPlayerIndex: starter, confirmedVisits: [...match.confirmedVisits, visit] };
    }
    const remaining = visit.result === 'bust' ? state.remaining : { ...state.remaining, [playerId]: visit.after.scores[playerId] ?? state.remaining[playerId] ?? 501 };
    return { ...match, state: { ...state, remaining }, currentPlayerIndex: (match.currentPlayerIndex + 1) % match.players.length, confirmedVisits: [...match.confirmedVisits, visit] };
  }
}
