import type { DartThrow } from '../darts/DartThrow';
import { bull, isDouble, notationOf, numberThrow, outerBull, scoreOf } from '../darts/DartThrow';

const options: readonly DartThrow[] = [
  ...Array.from({length: 20}, (_, i) => numberThrow(i + 1, 3)),
  ...Array.from({length: 20}, (_, i) => numberThrow(i + 1, 2)),
  ...Array.from({length: 20}, (_, i) => numberThrow(i + 1, 1)), outerBull(), bull()
];
const preferred = (route: readonly DartThrow[]): number => route.reduce((sum, d, i) => sum + (d.kind === 'number' && d.multiplier === 3 ? 0 : d.kind === 'bull' ? 2 : 1) + i, 0);
export function checkoutRoutes(remaining: number, dartsAvailable: number): readonly string[] {
  if (remaining < 2 || remaining > 170 || dartsAvailable < 1) return [];
  const found: DartThrow[][] = [];
  const search = (prefix: DartThrow[], left: number): void => {
    if (prefix.length >= dartsAvailable) return;
    for (const dart of options) {
      const next = left - scoreOf(dart); const route = [...prefix, dart];
      if (next === 0 && isDouble(dart)) found.push(route);
      else if (next > 1 && route.length < dartsAvailable) search(route, next);
      if (found.length > 100) return;
    }
  };
  search([], remaining);
  return found.sort((a,b) => a.length - b.length || preferred(a) - preferred(b)).slice(0,3).map(route => route.map(notationOf).join(' · '));
}
