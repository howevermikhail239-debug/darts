import type { VisitDraft } from '../match/VisitDraft';
import type { Match, Visit } from '../match/models';

export type DraftStatus = 'in_progress'|'ready_to_confirm'|'bust'|'leg_won'|'match_won';
export type DraftEvaluation = Readonly<{
  status: DraftStatus; physicalDartsUsed: number; rawScore: number; awardedScore: number;
  canAddNextDart: boolean; remainingAfter?: number; reason?: string; validDartCount: number;
}>;
export interface GameRules {
  evaluateDraft(draft: VisitDraft, match: Match): DraftEvaluation;
  applyConfirmedVisit(visit: Visit, match: Match): Match;
}
