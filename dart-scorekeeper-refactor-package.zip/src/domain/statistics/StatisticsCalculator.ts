import { notationOf, scoreOf } from '../darts/DartThrow';
import type { Match, PlayerId, Visit } from '../match/models';

export type PlayerStatistics = Readonly<{
  physicalDarts: number; visits: number; awardedPoints: number; rawPoints: number;
  averagePerDart: number; averagePerVisit: number; bestVisit: number; misses: number;
  outerBulls: number; bulls: number; singles: number; doubles: number; triples: number;
  hitCounts: Readonly<Record<string, number>>; positionScores: readonly [number, number, number];
  thresholds: Readonly<Record<'60+'|'80+'|'100+'|'120+'|'140+'|'180', number>>;
  winningDoubles: Readonly<Record<string, number>>; winningBulls: number; checkouts: readonly number[];
}>;
const zero = (): PlayerStatistics => ({ physicalDarts: 0, visits: 0, awardedPoints: 0, rawPoints: 0, averagePerDart: 0, averagePerVisit: 0, bestVisit: 0, misses: 0, outerBulls: 0, bulls: 0, singles: 0, doubles: 0, triples: 0, hitCounts: {}, positionScores: [0,0,0], thresholds: {'60+':0,'80+':0,'100+':0,'120+':0,'140+':0,'180':0}, winningDoubles: {}, winningBulls: 0, checkouts: [] });
export function statisticsForVisits(visits: readonly Visit[], playerId: PlayerId): PlayerStatistics {
  const own = visits.filter(v => v.playerId === playerId); const s = zero();
  const hitCounts: Record<string, number> = {}; const positions: [number,number,number] = [0,0,0]; const winningDoubles: Record<string,number> = {};
  let raw = 0, darts = 0, awarded = 0, best = 0, misses = 0, outerBulls = 0, bulls = 0, singles = 0, doubles = 0, triples = 0;
  const thresholds = {...s.thresholds}; const checkouts: number[] = []; let winningBulls = 0;
  own.forEach(visit => {
    darts += visit.physicalDartsUsed; raw += visit.rawScore; awarded += visit.awardedScore; best = Math.max(best, visit.rawScore);
    (['60+','80+','100+','120+','140+'] as const).forEach(key => { if (visit.rawScore >= Number(key.slice(0,-1))) thresholds[key] += 1; });
    if (visit.rawScore === 180) thresholds['180'] += 1;
    visit.darts.forEach((dart, index) => { const label = notationOf(dart); hitCounts[label] = (hitCounts[label] ?? 0) + 1; if(index < 3) positions[index] = (positions[index] ?? 0) + scoreOf(dart); if (dart.kind === 'miss') misses++; else if (dart.kind === 'outer_bull') outerBulls++; else if (dart.kind === 'bull') bulls++; else if (dart.multiplier === 1) singles++; else if (dart.multiplier === 2) doubles++; else triples++; });
    if (visit.result === 'leg_won' || visit.result === 'match_won') { const last = visit.darts.at(-1); if (last?.kind === 'bull') winningBulls++; else if (last) { const label=notationOf(last); winningDoubles[label]=(winningDoubles[label]??0)+1; } checkouts.push(visit.rawScore); }
  });
  return { physicalDarts: darts, visits: own.length, awardedPoints: awarded, rawPoints: raw, averagePerDart: darts ? awarded/darts : 0, averagePerVisit: own.length ? awarded/own.length : 0, bestVisit: best, misses, outerBulls, bulls, singles, doubles, triples, hitCounts, positionScores: positions, thresholds, winningDoubles, winningBulls, checkouts };
}
export const statisticsForMatch = (match: Match): Readonly<Record<PlayerId, PlayerStatistics>> => Object.fromEntries(match.players.map(id => [id, statisticsForVisits(match.confirmedVisits, id)]));
