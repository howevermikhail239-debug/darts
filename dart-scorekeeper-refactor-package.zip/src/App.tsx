import { useEffect, useState } from "react";
import { createMatch, type MatchSetup } from "./domain/match/createMatch";
import type { Match, Player } from "./domain/match/models";
import { GameSession, type SessionSnapshot } from "./application/GameSession";
import { services } from "./app/compositionRoot";
import { SetupPage } from "./presentation/pages/SetupPage";
import { GamePage } from "./presentation/pages/GamePage";
import { HistoryPage } from "./presentation/pages/HistoryPage";
import "./presentation/styles.css";
import "./presentation/concept-overrides.css";

type Screen = "loading" | "home" | "game" | "history";
export default function App() {
  const [screen, setScreen] = useState<Screen>("loading");
  const [players, setPlayers] = useState<readonly Player[]>([]);
  const [history, setHistory] = useState<readonly Match[]>([]);
  const [session, setSession] = useState<GameSession>();
  const [snapshot, setSnapshot] = useState<SessionSnapshot>();
  const [resume, setResume] = useState<{
    session: GameSession;
    snapshot: SessionSnapshot;
  }>();
  const [fatal, setFatal] = useState<string>();
  useEffect(() => {
    void Promise.all([
      services.players.list(),
      services.matches.listHistory(),
      services.matches.loadActive(),
    ])
      .then(([p, h, a]) => {
        setPlayers(p);
        setHistory(h);
        if (
          a?.current.status === "in_progress" ||
          a?.current.status === "completed"
        ) {
          const s = new GameSession(
            a.current,
            services.matches,
            services.id,
            services.now,
            a.previous,
          );
          const base = s.snapshot();
          setResume({
            session: s,
            snapshot:
              a.current.status === "in_progress"
                ? {
                    ...base,
                    notice:
                      "Незавершённый подход был сброшен. Введите его заново.",
                  }
                : base,
          });
        }
        setScreen("home");
      })
      .catch((e) => {
        setFatal(
          e instanceof Error ? e.message : "Ошибка локального хранилища",
        );
        setScreen("home");
      });
  }, []);
  const start = async (names: readonly string[], setup: MatchSetup) => {
    const now = services.now();
    const findOrCreate = async (name: string) => {
      const existing = players.find(
        (p) => p.name.toLocaleLowerCase() === name.toLocaleLowerCase(),
      );
      if (existing) return existing;
      const p: Player = { id: services.id(), name, createdAt: now };
      await services.players.save(p);
      return p;
    };
    const selectedPlayers = await Promise.all(names.map(findOrCreate));
    const selectedIds = new Set(selectedPlayers.map((player) => player.id));
    const all = [
      ...players.filter((player) => !selectedIds.has(player.id)),
      ...selectedPlayers,
    ];
    setPlayers(all);
    const match = createMatch(
      services.id(),
      selectedPlayers.map((player) => player.id),
      setup,
      now,
    );
    await services.matches.saveActive({ current: match });
    const s = new GameSession(
      match,
      services.matches,
      services.id,
      services.now,
    );
    setSession(s);
    setSnapshot(s.snapshot());
    setResume(undefined);
    setScreen("game");
  };
  const leave = async () => {
    setSession(undefined);
    setSnapshot(undefined);
    setResume(undefined);
    setHistory(await services.matches.listHistory());
    setScreen("home");
  };
  if (screen === "loading")
    return <main className="loading">Загружаем дартс…</main>;
  if (screen === "game" && session && snapshot)
    return (
      <GamePage
        key={snapshot.match.id}
        session={session}
        initial={snapshot}
        players={players}
        onChange={setSnapshot}
        onExit={() => void leave()}
      />
    );
  if (screen === "history")
    return (
      <HistoryPage
        matches={history}
        players={players}
        onBack={() => setScreen("home")}
      />
    );
  return (
    <>
      {fatal ? <div className="fatal" role="alert">{fatal} <button className="secondary" onClick={()=>void services.clearLocalData().then(()=>location.reload())}>Сбросить повреждённые данные</button></div> : null}
      {resume ? (
        <aside className="resume">
          <div>
            <b>Продолжить матч</b>
            <span>
              {resume.snapshot.match.mode === "x01" ? "501" : "Серия"} ·
              подтверждённых подходов:{" "}
              {resume.snapshot.match.confirmedVisits.length}
            </span>
          </div>
          <button
            className="primary"
            onClick={() => {
              setSession(resume.session);
              setSnapshot(resume.snapshot);
              setScreen("game");
            }}
          >
            Продолжить
          </button>
          <button
            className="secondary"
            onClick={() => void resume.session.abandon().then(leave)}
          >
            Прервать матч
          </button>
        </aside>
      ) : null}
      <SetupPage
        saved={players}
        onStart={start}
        onHistory={() => setScreen("history")}
      />
    </>
  );
}
