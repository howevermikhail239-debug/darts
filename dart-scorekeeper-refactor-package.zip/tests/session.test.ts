import { describe, expect, it } from "vitest";
import { GameSession } from "../src/application/GameSession";
import type {
  ActiveMatchRecord,
  MatchRepository,
} from "../src/application/ports/repositories";
import { createMatch } from "../src/domain/match/createMatch";
import { bull, miss, numberThrow } from "../src/domain/darts/DartThrow";
import { statisticsForMatch } from "../src/domain/statistics/StatisticsCalculator";
class MemoryRepo implements MatchRepository {
  active: ActiveMatchRecord | undefined;
  history: import("../src/domain/match/models").Match[] = [];
  async saveActive(r: ActiveMatchRecord) {
    this.active = structuredClone(r);
  }
  async loadActive() {
    return this.active;
  }
  async clearActive() {
    this.active = undefined;
  }
  async saveToHistory(m: import("../src/domain/match/models").Match) {
    this.history.push(m);
  }
  async archiveAndClearActive(m: import("../src/domain/match/models").Match) {
    this.history.push(m);
    this.active = undefined;
  }
  async listHistory() {
    return this.history;
  }
}
class DeferredRepo extends MemoryRepo {
  release: (() => void) | undefined;
  override async saveActive(record: ActiveMatchRecord) {
    await new Promise<void>((resolve) => {
      this.release = resolve;
    });
    await super.saveActive(record);
  }
}
let seq = 0;
const id = () => `id-${++seq}`,
  clock = () => `2026-09-07T12:00:0${seq}.000Z`;
const withRemaining = (
  m: import("../src/domain/match/models").Match,
  a: number,
) => {
  if (m.state.kind !== "x01") throw new Error("test setup");
  return {
    ...m,
    state: { ...m.state, remaining: { a, b: 501 } },
  } as import("../src/domain/match/models").Match;
};
describe("GameSession", () => {
  it("creates a deeply immutable confirmed visit", async () => {
    const repo = new MemoryRepo();
    const match = createMatch("immutable", ["a", "b"], { mode: "fixed_visits", visitsPerPlayer: 1, startingPlayerIndex: 0 }, clock());
    const session = new GameSession(match, repo, id, clock);
    session.record(miss()); session.record(miss()); session.record(miss());
    await session.confirm();
    const visit = session.snapshot().match.confirmedVisits[0]!;
    expect(Object.isFrozen(visit.darts)).toBe(true);
    expect(Object.isFrozen(visit.before)).toBe(true);
    expect(Object.isFrozen(visit.before.scores)).toBe(true);
    expect(Object.isFrozen(visit.after)).toBe(true);
    expect(Object.isFrozen(visit.after.scores)).toBe(true);
  });
  it("draft cannot mutate match and confirmation is atomic", async () => {
    const repo = new MemoryRepo(),
      m = createMatch(
        "m",
        ["a", "b"],
        { mode: "x01", targetLegWins: 2, startingPlayerIndex: 0 },
        clock(),
      );
    const s = new GameSession(m, repo, id, clock);
    s.record(numberThrow(20, 3));
    expect(s.snapshot().match.state).toEqual(m.state);
    s.record(numberThrow(20, 3));
    s.record(numberThrow(20, 3));
    await Promise.all([s.confirm(), s.confirm()]);
    expect(s.snapshot().match.confirmedVisits).toHaveLength(1);
    expect(repo.active?.current.confirmedVisits).toHaveLength(1);
    expect(s.snapshot().match.currentPlayerIndex).toBe(1);
  });
  it("undo fully restores bust and survives reload", async () => {
    const repo = new MemoryRepo(),
      m = createMatch(
        "m",
        ["a", "b"],
        { mode: "x01", targetLegWins: 2, startingPlayerIndex: 0 },
        clock(),
      );
    const near = withRemaining(m, 32);
    const s = new GameSession(near, repo, id, clock);
    s.record(numberThrow(20, 3));
    await s.confirm();
    expect(s.snapshot().match.confirmedVisits[0]?.result).toBe("bust");
    const persisted = await repo.loadActive();
    const reloaded = new GameSession(
      persisted!.current,
      repo,
      id,
      clock,
      persisted!.previous,
    );
    await reloaded.undo();
    expect(reloaded.snapshot().match).toEqual(near);
  });
  it("undo reopens a completed match", async () => {
    const repo = new MemoryRepo(),
      m = createMatch(
        "m",
        ["a", "b"],
        { mode: "x01", targetLegWins: 1, startingPlayerIndex: 0 },
        clock(),
      );
    const near = withRemaining(m, 50);
    const s = new GameSession(near, repo, id, clock);
    s.record(bull());
    await s.confirm();
    expect(s.snapshot().match.status).toBe("completed");
    await s.undo();
    expect(s.snapshot().match.status).toBe("in_progress");
  });
  it("fixed series gives equal visits then handles tie and extra round", async () => {
    const repo = new MemoryRepo(),
      m = createMatch(
        "m",
        ["a", "b"],
        { mode: "fixed_visits", visitsPerPlayer: 1, startingPlayerIndex: 0 },
        clock(),
      );
    const s = new GameSession(m, repo, id, clock);
    for (let p = 0; p < 2; p++) {
      s.record(miss());
      s.record(miss());
      s.record(miss());
      await s.confirm();
    }
    expect(s.snapshot().match.state).toMatchObject({
      awaitingTieDecision: true,
      regulationCompleted: { a: 1, b: 1 },
    });
    await s.extraRound();
    for (let p = 0; p < 2; p++) {
      s.record(p === 0 ? numberThrow(20, 3) : miss());
      s.record(miss());
      s.record(miss());
      await s.confirm();
    }
    expect(s.snapshot().match).toMatchObject({
      status: "completed",
      winnerId: "a",
    });
  });
  it("statistics derive raw hits and awarded bust points", async () => {
    const repo = new MemoryRepo(),
      m = createMatch(
        "m",
        ["a", "b"],
        { mode: "x01", targetLegWins: 2, startingPlayerIndex: 0 },
        clock(),
      );
    const near = withRemaining(m, 32);
    const s = new GameSession(near, repo, id, clock);
    s.record(numberThrow(20, 3));
    await s.confirm();
    const stat = statisticsForMatch(s.snapshot().match).a!;
    expect(stat).toMatchObject({
      physicalDarts: 1,
      rawPoints: 60,
      awardedPoints: 0,
      triples: 1,
    });
  });
  it("publishes busy synchronously and rejects every competing mutation", async () => {
    const repo = new DeferredRepo();
    const match = createMatch(
      "busy",
      ["a", "b"],
      { mode: "fixed_visits", visitsPerPlayer: 5, startingPlayerIndex: 0 },
      clock(),
    );
    const session = new GameSession(match, repo, id, clock);
    session.record(miss()); session.record(miss()); session.record(miss());
    const pending = session.confirm();
    expect(session.snapshot().isConfirming).toBe(true);
    expect(() => session.record(miss())).toThrow("Подтверждение уже выполняется");
    expect(() => session.reset()).toThrow("Подтверждение уже выполняется");
    await expect(session.undo()).rejects.toThrow("Подтверждение уже выполняется");
    repo.release?.();
    await pending;
    expect(session.snapshot().match.confirmedVisits).toHaveLength(1);
  });
  it.each([2, 3, 5, 8])("cycles turns across %i players", async (count) => {
    const ids = Array.from({ length: count }, (_, index) => `p${index}`);
    const repo = new MemoryRepo();
    const match = createMatch("many", ids, { mode: "fixed_visits", visitsPerPlayer: 1, startingPlayerIndex: count - 1 }, clock());
    const session = new GameSession(match, repo, id, clock);
    const seen: string[] = [];
    for (let turn = 0; turn < count; turn += 1) {
      seen.push(session.snapshot().match.players[session.snapshot().match.currentPlayerIndex]!);
      session.record(miss()); session.record(miss()); session.record(miss());
      await session.confirm();
    }
    expect(seen).toEqual([ids.at(-1), ...ids.slice(0, -1)]);
    expect(session.snapshot().match.state).toMatchObject({ regulationCompleted: Object.fromEntries(ids.map((playerId) => [playerId, 1])), awaitingTieDecision: true });
  });
});
