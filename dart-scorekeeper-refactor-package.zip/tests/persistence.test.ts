import "fake-indexeddb/auto";
import { afterEach, describe, expect, it } from "vitest";
import {
  IndexedDbMatchRepository,
  clearLocalData,
} from "../src/infrastructure/persistence/IndexedDbRepositories";
import { createMatch } from "../src/domain/match/createMatch";
describe("IndexedDB repository", () => {
  afterEach(() => clearLocalData());
  it("persists current and previous checkpoint", async () => {
    const repo = new IndexedDbMatchRepository(),
      m = createMatch(
        "m",
        ["a", "b"],
        { mode: "x01", targetLegWins: 2, startingPlayerIndex: 0 },
        new Date().toISOString(),
      );
    await repo.saveActive({ current: m, previous: m });
    expect(await repo.loadActive()).toEqual({ current: m, previous: m });
  });
});
