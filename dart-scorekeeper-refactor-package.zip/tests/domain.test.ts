import { describe, expect, it } from "vitest";
import {
  bull,
  miss,
  numberThrow,
  outerBull,
  scoreOf,
} from "../src/domain/darts/DartThrow";
import {
  addDraftThrow,
  emptyDraft,
  removeDraftThrow,
  replaceDraftThrow,
  resetDraft,
} from "../src/domain/match/VisitDraft";
import { createMatch } from "../src/domain/match/createMatch";
import { X01Rules } from "../src/domain/rules/X01Rules";
import { FixedVisitsRules } from "../src/domain/rules/FixedVisitsRules";
import { checkoutRoutes } from "../src/domain/rules/CheckoutRoutes";
import type { Match } from "../src/domain/match/models";
const now = "2026-09-07T12:00:00.000Z";
const xmatch = (remaining = 501, targetLegWins = 2): Match => {
  const m = createMatch(
    "m",
    ["a", "b"],
    { mode: "x01", targetLegWins, startingPlayerIndex: 0 },
    now,
  );
  if (m.state.kind !== "x01") throw new Error("test setup");
  return { ...m, state: { ...m.state, remaining: { a: remaining, b: 501 } } };
};
const draft = (...darts: ReturnType<typeof miss>[]) =>
  darts.reduce(addDraftThrow, emptyDraft());
describe("DartThrow", () => {
  it("scores every category", () => {
    expect([
      scoreOf(numberThrow(20, 1)),
      scoreOf(numberThrow(20, 2)),
      scoreOf(numberThrow(20, 3)),
      scoreOf(outerBull()),
      scoreOf(bull()),
      scoreOf(miss()),
    ]).toEqual([20, 40, 60, 25, 50, 0]);
  });
  it("rejects invalid sectors", () =>
    expect(() => numberThrow(21, 3)).toThrow());
  it("rejects an invalid multiplier at the runtime boundary", () =>
    expect(() => numberThrow(20, 4 as never)).toThrow());
});
describe("VisitDraft", () => {
  it("adds, replaces, removes and resets immutably", () => {
    const base = emptyDraft();
    const one = addDraftThrow(base, miss());
    const three = addDraftThrow(addDraftThrow(one, numberThrow(20, 3)), bull());
    expect(base.darts).toHaveLength(0);
    expect(three.darts).toHaveLength(3);
    expect(() => addDraftThrow(three, miss())).toThrow();
    expect(replaceDraftThrow(three, 0, outerBull()).darts[0]?.kind).toBe(
      "outer_bull",
    );
    expect(removeDraftThrow(three).darts).toHaveLength(2);
    expect(resetDraft().darts).toHaveLength(0);
  });
  it("MISS occupies a physical slot", () =>
    expect(addDraftThrow(emptyDraft(), miss()).darts).toHaveLength(1));
});
describe("X01Rules", () => {
  const rules = new X01Rules();
  it("evaluates normal score and 180", () => {
    expect(
      rules.evaluateDraft(
        draft(numberThrow(20, 3), numberThrow(20, 3), numberThrow(20, 3)),
        xmatch(),
      ),
    ).toMatchObject({
      status: "ready_to_confirm",
      rawScore: 180,
      remainingAfter: 321,
    });
  });
  it.each([
    [32, [numberThrow(20, 3)], "bust"],
    [2, [numberThrow(1, 1)], "bust"],
    [20, [numberThrow(20, 1)], "bust"],
  ] as const)("detects bust from %s", (remaining, darts, status) =>
    expect(
      rules.evaluateDraft(draft(...darts), xmatch(remaining)),
    ).toMatchObject({
      status,
      awardedScore: 0,
      remainingAfter: remaining,
      canAddNextDart: false,
    }),
  );
  it("D20 and Bull close while requiring confirmation", () => {
    expect(
      rules.evaluateDraft(draft(numberThrow(20, 2)), xmatch(40)),
    ).toMatchObject({ status: "leg_won", remainingAfter: 0 });
    expect(rules.evaluateDraft(draft(bull()), xmatch(50))).toMatchObject({
      status: "leg_won",
      remainingAfter: 0,
    });
  });
  it("reports match win at target", () => {
    const m = xmatch(40, 1);
    expect(rules.evaluateDraft(draft(numberThrow(20, 2)), m).status).toBe(
      "match_won",
    );
  });
  it("offers Bull notation for checkout", () =>
    expect(checkoutRoutes(50, 1)).toContain("Bull"));
});
describe("FixedVisitsRules", () => {
  it("requires exactly three darts and sums misses", () => {
    const rules = new FixedVisitsRules(),
      m = createMatch(
        "m",
        ["a", "b"],
        { mode: "fixed_visits", visitsPerPlayer: 5, startingPlayerIndex: 0 },
        now,
      );
    expect(
      rules.evaluateDraft(draft(numberThrow(20, 3), miss()), m).status,
    ).toBe("in_progress");
    expect(
      rules.evaluateDraft(
        draft(numberThrow(20, 3), miss(), numberThrow(20, 1)),
        m,
      ),
    ).toMatchObject({ status: "ready_to_confirm", rawScore: 80 });
  });
  it.each([5, 10, 20, 30, 37])("accepts %i visits", (n) =>
    expect(
      createMatch(
        "m",
        ["a", "b"],
        { mode: "fixed_visits", visitsPerPlayer: n, startingPlayerIndex: 0 },
        now,
      ).state,
    ).toMatchObject({ visitsPerPlayer: n }),
  );
});
